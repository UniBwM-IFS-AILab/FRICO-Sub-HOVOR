from hovor.runtime.fields_container import FieldsContainer


class Context(FieldsContainer):
   pass