from hovor.actions.action_base import ActionBase


class SystemAction(ActionBase):
    """System type of action."""
    pass
